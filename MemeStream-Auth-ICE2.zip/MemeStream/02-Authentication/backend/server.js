import express from 'express';
import dotenv from 'dotenv';
import verifyFirebaseIdToken from './auth-middleware.js';

dotenv.config();
const app = express();
app.use(express.json());

// Public route
app.get('/', (req, res) => res.send('MemeStream Auth Backend'));

// Protected route example: verifies Firebase ID token sent in Authorization: Bearer <token>
app.get('/profile', verifyFirebaseIdToken, (req, res) => {
  // verifyFirebaseIdToken sets req.user
  res.json({ message: 'Protected profile', user: req.user });
});

const port = process.env.PORT || 4000;
app.listen(port, () => console.log(`Auth backend listening on ${port}`));
