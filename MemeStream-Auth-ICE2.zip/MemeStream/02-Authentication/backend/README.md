# MemeStream Auth Backend (Node.js)

This small backend demonstrates verifying Firebase ID tokens (issued by Firebase Authentication / Google Sign-In)
for protecting API endpoints.

## Setup
1. Create a Firebase service account JSON in the Firebase Console → Project Settings → Service accounts → Generate new private key.
2. Place the JSON file in `backend/` and set environment variable `SERVICE_ACCOUNT_PATH` in `backend/.env` (or name the file `serviceAccountKey.json`).
3. Install dependencies:
   ```bash
   cd backend
   npm install
   ```
4. Start server:
   ```bash
   npm start
   ```
5. Call protected route with Authorization header:
   `Authorization: Bearer <Firebase ID token>`

You get the Firebase ID token client-side after signing in (`FirebaseAuth.getInstance().getCurrentUser().getIdToken(...)` in Android).
