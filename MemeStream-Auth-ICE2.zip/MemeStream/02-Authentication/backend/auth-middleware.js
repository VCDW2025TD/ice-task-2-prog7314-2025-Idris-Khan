import admin from 'firebase-admin';
import fs from 'fs';
import dotenv from 'dotenv';

dotenv.config();

// Initialize firebase-admin using a service account JSON file path set in SERVICE_ACCOUNT_PATH
if (!admin.apps.length) {
  const serviceAccountPath = process.env.SERVICE_ACCOUNT_PATH || './serviceAccountKey.json';
  if (!fs.existsSync(serviceAccountPath)) {
    console.warn('firebase-admin service account JSON not found. Please add one and set SERVICE_ACCOUNT_PATH in .env');
  } else {
    admin.initializeApp({
      credential: admin.credential.cert(serviceAccountPath)
    });
  }
}

export default async function verifyFirebaseIdToken(req, res, next) {
  const authHeader = req.headers.authorization || '';
  const match = authHeader.match(/^Bearer (.+)$/);
  if (!match) return res.status(401).json({ error: 'Missing Authorization header with Bearer token' });
  const idToken = match[1];

  try {
    const decoded = await admin.auth().verifyIdToken(idToken);
    req.user = decoded;
    next();
  } catch (err) {
    console.error('Token verification error:', err);
    res.status(401).json({ error: 'Invalid or expired token' });
  }
}
