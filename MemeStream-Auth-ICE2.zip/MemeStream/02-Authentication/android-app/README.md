# MemeStream Android Auth App (Kotlin)

This sample Android app demonstrates:
- Google Sign-In (SSO) integrated with Firebase Authentication
- BiometricPrompt (fingerprint / face) gating the sign-in flow

IMPORTANT SETUP STEPS (you MUST do these before building):
1. Create a Firebase project at https://console.firebase.google.com/
2. In Firebase Console → Authentication → Sign-in method → Enable Google
3. Create an Android app in Firebase and download `google-services.json`. Place it in `android-app/app/`.
4. In Firebase → Project settings → OAuth 2.0 Client IDs, copy the **Web client (client ID)** and replace `SERVER_CLIENT_ID`
   string in `MainActivity.kt` (the `.requestIdToken("SERVER_CLIENT_ID")` line).
5. Build and run on a physical device or emulator with Google Play services and biometric support.

This app first asks for biometric authentication; on success it opens Google Sign-In and then signs into Firebase
using the Google ID token.
