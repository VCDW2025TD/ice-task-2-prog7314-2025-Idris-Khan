package com.memestream

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import java.util.concurrent.Executor

class MainActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var statusText: TextView
    private lateinit var executor: Executor

    private val googleSignInResult = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val task = GoogleSignIn.getSignedInAccountFromIntent(result.data)
            try {
                val account = task.getResult(ApiException::class.java)!!
                val idToken = account.idToken
                if (idToken != null) {
                    val credential = GoogleAuthProvider.getCredential(idToken, null)
                    auth.signInWithCredential(credential)
                        .addOnCompleteListener(this) { task2 ->
                            if (task2.isSuccessful) {
                                statusText.text = "Signed in: " + (auth.currentUser?.email ?: "unknown")
                            } else {
                                statusText.text = "Firebase auth failed: " + (task2.exception?.message ?: "") 
                            }
                        }
                } else {
                    statusText.text = "Google ID token is null"
                }
            } catch (e: ApiException) {
                statusText.text = "Google sign-in failed: " + e.statusCode
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        auth = FirebaseAuth.getInstance()
        statusText = findViewById(R.id.statusText)
        executor = ContextCompat.getMainExecutor(this)

        val biometricButton = findViewById<Button>(R.id.btnBiometric)
        val googleButton = findViewById<Button>(R.id.btnGoogle)

        biometricButton.setOnClickListener {
            showBiometricPrompt()
        }

        googleButton.setOnClickListener {
            startGoogleSignIn()
        }

        // If already signed in
        auth.currentUser?.let {
            statusText.text = "Signed in: ${it.email}"
        }
    }

    private fun showBiometricPrompt() {
        val prompt = BiometricPrompt(this, executor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                super.onAuthenticationSucceeded(result)
                statusText.text = "Biometric auth succeeded — now trigger Google Sign-In"
                // After biometric succeeds, start Google sign-in to get token and link with Firebase
                startGoogleSignIn()
            }

            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                super.onAuthenticationError(errorCode, errString)
                statusText.text = "Biometric error: $errString"
            }

            override fun onAuthenticationFailed() {
                super.onAuthenticationFailed()
                statusText.text = "Biometric failed"
            }
        })

        val promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle("MemeStream login")
            .setSubtitle("Authenticate to continue")
            .setNegativeButtonText("Use account password")
            .build()

        prompt.authenticate(promptInfo)
    }

    private fun startGoogleSignIn() {
        // NOTE: replace SERVER_CLIENT_ID with your OAuth 2.0 Web client ID from Firebase console
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken("SERVER_CLIENT_ID")
            .requestEmail()
            .build()

        val client = GoogleSignIn.getClient(this, gso)
        val signInIntent = client.signInIntent
        googleSignInResult.launch(signInIntent)
    }
}
