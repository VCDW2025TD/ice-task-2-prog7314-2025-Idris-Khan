# MemeStream - Step 3: Authentication (SSO + Biometric)

This folder contains:
- `android-app/` — A sample Android app (Kotlin) demonstrating BiometricPrompt + Google Sign-In (Firebase Auth).
- `backend/` — A tiny Node.js backend that shows how to verify Firebase ID tokens for protected endpoints.

Follow the READMEs inside each folder for setup steps and deployment notes.
